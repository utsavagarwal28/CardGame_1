using UnityEngine;
using TMPro;
using UnityEngine.UI;
using Unity.Services.Lobbies.Models;
using System.Threading.Tasks;
using AuthenticationManager = Game.Authentication.AuthenticationManager;

namespace Game.Lobby.LobbyCanvas
{
    public class SessionPlayerListItem : MonoBehaviour
    {
        [SerializeField] private TMP_Text playerNameText;
        [SerializeField] Button kickButton;

        private Player player;

        private void Awake()
        {
            System.Func<Task> waitForAuthenticationAndLobby = async () =>
            {
                while (AuthenticationManager.Instance == null || !AuthenticationManager.Instance.IsAuthenticated)
                    await Task.Yield();

                while (LobbyManager.Instance == null)
                    await Task.Yield();
            };
        }

        public void SetPlayer(Player p)
        {
            player = p;

            string displayName = p.Data != null && p.Data.ContainsKey("DisplayName")
                ? p.Data["DisplayName"].Value
                : p.Id;

            playerNameText.text = displayName;

            bool isHost = LobbyManager.Instance.IsHost();
            bool isLocal = p.Id == AuthenticationManager.Instance.GetPlayerID();

            kickButton.gameObject.SetActive(isHost && !isLocal);

            kickButton.onClick.RemoveAllListeners();
            kickButton.onClick.AddListener(() =>
            {
                LobbyManager.Instance.KickPlayer(p.Id);
            });
        }
    }
}