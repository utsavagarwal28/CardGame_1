using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Threading.Tasks;
using Game.Authentication;

namespace Game.Lobby.LobbyCanvas
{
    public class ShowJoinCodeUI : MonoBehaviour
    {
        [SerializeField] private TMP_Text joinCodeText;
        [SerializeField] private Button copyButton;

        private void Awake()
        {
            System.Func<Task> waitForAuthenticationAndLobby = async () =>
            {
                while (AuthenticationManager.Instance == null || !AuthenticationManager.Instance.IsAuthenticated)
                    await Task.Yield();

                while (LobbyManager.Instance == null)
                    await Task.Yield();
            };
        }

        private void Update()
        {
            if (LobbyManager.Instance.CurrentLobby != null)
                joinCodeText.text = LobbyManager.Instance.CurrentLobby.LobbyCode;
        }

        private void Start()
        {
            copyButton.onClick.AddListener(() =>
            {
                GUIUtility.systemCopyBuffer = joinCodeText.text;
            });
        }
    }
}