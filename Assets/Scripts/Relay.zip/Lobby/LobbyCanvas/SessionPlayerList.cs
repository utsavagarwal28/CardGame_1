using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using System.Threading.Tasks;
using Unity.Services.Lobbies.Models;
using Game.Authentication;

namespace Game.Lobby.LobbyCanvas
{
    public class SessionPlayerList : MonoBehaviour
    {
        [SerializeField] private Transform content;
        [SerializeField] private GameObject playerListItemPrefab;

        private void Awake()
        {
            System.Func<Task> waitForAuthenticationAndLobby = async () =>
            {
                while (AuthenticationManager.Instance == null || !AuthenticationManager.Instance.IsAuthenticated)
                    await Task.Yield();

                while (LobbyManager.Instance == null)
                    await Task.Yield();
            };
        }

        private void OnEnable()
        {
            LobbyManager.OnLobbyUpdated += RefreshPlayerList;
            RefreshPlayerList();
        }

        public void RefreshPlayerList()
        {
            foreach (Transform child in content)
                Destroy(child.gameObject);

            if (LobbyManager.Instance.CurrentLobby == null) return;

            foreach (Player player in LobbyManager.Instance.CurrentLobby.Players)
            {
                GameObject item = Instantiate(playerListItemPrefab, content);
                item.SetActive(true);
                item.GetComponent<SessionPlayerListItem>().SetPlayer(player);
            }
        }
    }
}
