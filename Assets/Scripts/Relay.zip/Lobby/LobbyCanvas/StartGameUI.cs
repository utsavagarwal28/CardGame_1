using UnityEngine;
using UnityEngine.UI;
using System.Threading.Tasks;
using Game.Authentication;

namespace Game.Lobby.LobbyCanvas
{
    namespace Game.Lobby.LobbyCanvas
    {
        public class StartGameUI : MonoBehaviour
        {
            [SerializeField] private Button startGameButton;

            private void Awake()
            {
                System.Func<Task> waitForAuthenticationAndLobby = async () =>
                {
                    while (AuthenticationManager.Instance == null || !AuthenticationManager.Instance.IsAuthenticated)
                        await Task.Yield();

                    while (LobbyManager.Instance == null)
                        await Task.Yield();
                };
            }

            private void Update()
            {
                var lobby = LobbyManager.Instance.CurrentLobby;
                bool isHost = LobbyManager.Instance.IsHost();
                bool full = lobby != null && lobby.Players.Count == 4;

                startGameButton.interactable = isHost && full;
            }

            private void Start()
            {
                startGameButton.onClick.AddListener(() =>
                {
                    LobbyManager.Instance.StartGame();
                });
            }
        }
    }
}