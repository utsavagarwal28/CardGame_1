using UnityEngine;
using UnityEngine.UI;
using System.Threading.Tasks;
using Game.Authentication;

namespace Game.Lobby.LobbyCanvas
{
    public class LeaveSessionUI : MonoBehaviour
    {
        public Button leaveButton;

        private void Awake()
        {
            System.Func<Task> waitForAuthenticationAndLobby = async () =>
            {
                while (AuthenticationManager.Instance == null || !AuthenticationManager.Instance.IsAuthenticated)
                    await Task.Yield();

                while (LobbyManager.Instance == null)
                    await Task.Yield();
            };
        }

        private void Start()
        {
            leaveButton.onClick.AddListener(() =>
            {
                LobbyManager.Instance.LeaveLobby();
            });
        }
    }
}