using UnityEngine;
using Unity.Services.Lobbies;
using Unity.Services.Lobbies.Models;
using LobbyClass = Unity.Services.Lobbies.Models.Lobby;
using System.Collections.Generic;
using System.Threading.Tasks;
using Game.Lobby.LobbyCanvas;
using Game.Relay;
using Game.Authentication;
using System;


namespace Game.Lobby
{
    public class LobbyManager : MonoBehaviour
    {
        public static LobbyManager Instance;
        public LobbyClass CurrentLobby { get; private set; }
        public static event Action OnLobbyUpdated;
        async void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            while (AuthenticationManager.Instance == null)
                await Task.Yield();

            // Wait while authentication is not complete
            while (!AuthenticationManager.Instance.IsAuthenticated)
                await Task.Yield();
        }

        public async Task<LobbyClass> CreateLobbyAsync(string lobbyName, int maxPlayers)
        {
            var player = new Player()
            {
                Data = new Dictionary<string, PlayerDataObject>
                {
                    {"DisplayName", new PlayerDataObject(PlayerDataObject.VisibilityOptions.Public, AuthenticationManager.Instance.GetPlayerID()) }
                }
            };

            var options = new CreateLobbyOptions { Player = player };
            var lobby = await LobbyService.Instance.CreateLobbyAsync(lobbyName, maxPlayers, options);
            UpdateLobbyData(lobby);

            await RelayManager.Instance.CreateRelayAsync();
            await LobbyService.Instance.UpdateLobbyAsync(lobby.Id, new UpdateLobbyOptions()
            {
                Data = new Dictionary<string, DataObject>
                {
                    {"JoinCode",  new DataObject(DataObject.VisibilityOptions.Public, RelayManager.Instance.JoinCode)}
                }
            });
            return lobby;
        }

        public async Task<LobbyClass> JoinLobbyByCodeAsync(string joinCode)
        {
            var player = new Player()
            {
                Data = new Dictionary<string, PlayerDataObject>
                {
                    {"DisplayName", new PlayerDataObject(PlayerDataObject.VisibilityOptions.Public, AuthenticationManager.Instance.GetPlayerID()) }
                }
            };

            var lobby = await LobbyService.Instance.JoinLobbyByCodeAsync(joinCode, new JoinLobbyByCodeOptions { Player = player });
            CurrentLobby = lobby;

            string relayJoinCode = lobby.Data["JoinCode"].Value;
            await RelayManager.Instance.JoinRelayAsync(relayJoinCode);
            UpdateLobbyData(lobby);

            return lobby;
        }

        private void UpdateLobbyData(LobbyClass newLobby)
        {
            CurrentLobby = newLobby;
            OnLobbyUpdated?.Invoke();
        }

        public bool IsHost()
        {
            return CurrentLobby != null && CurrentLobby.HostId == AuthenticationManager.Instance.GetPlayerID();
        }

        public async void KickPlayer(string playerId)
        {
            if (!IsHost()) return;

            try
            {
                await LobbyService.Instance.RemovePlayerAsync(CurrentLobby.Id, playerId);
                Debug.Log($"Kicked player with ID: {playerId}");
            }
            catch (Exception e)
            {
                Debug.LogError($"Failed to kick player: {e.Message}");
            }
        }

        public void StartGame()
        {
            if (!IsHost()) return;

            Debug.Log("Starting Game...");
            Unity.Netcode.NetworkManager.Singleton.SceneManager.LoadScene("GameScene", UnityEngine.SceneManagement.LoadSceneMode.Single);
        }

        public async void LeaveLobby()
        {
            if (CurrentLobby != null)
            {
                try
                {
                    await LobbyService.Instance.RemovePlayerAsync(CurrentLobby.Id, AuthenticationManager.Instance.GetPlayerID());
                    Debug.Log("Left the lobby.");
                    CurrentLobby = null;
                    OnLobbyUpdated?.Invoke();
                }
                catch (Exception e)
                {
                    Debug.LogError($"Error leaving the lobby: {e.Message}");
                }
            }
        }
    }
}
